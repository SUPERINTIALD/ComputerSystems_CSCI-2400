/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_425(unsigned *p)
{
    *p = 2462550344U;
}

unsigned addval_115(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_368(unsigned x)
{
    return x + 3837941955U;
}

unsigned getval_239()
{
    return 465801304U;
}

unsigned getval_327()
{
    return 3284633928U;
}

unsigned addval_231(unsigned x)
{
    return x + 1791056007U;
}

unsigned addval_258(unsigned x)
{
    return x + 2425379030U;
}

void setval_491(unsigned *p)
{
    *p = 3251079496U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_363(unsigned *p)
{
    *p = 3534012809U;
}

void setval_282(unsigned *p)
{
    *p = 3375939977U;
}

void setval_256(unsigned *p)
{
    *p = 3286272328U;
}

void setval_328(unsigned *p)
{
    *p = 3767093248U;
}

unsigned addval_420(unsigned x)
{
    return x + 3375939979U;
}

unsigned getval_113()
{
    return 3526937225U;
}

unsigned getval_338()
{
    return 3221804681U;
}

unsigned addval_186(unsigned x)
{
    return x + 3374372361U;
}

void setval_306(unsigned *p)
{
    *p = 3286288712U;
}

unsigned getval_167()
{
    return 3687104905U;
}

void setval_394(unsigned *p)
{
    *p = 3526410633U;
}

unsigned addval_234(unsigned x)
{
    return x + 3286280520U;
}

unsigned addval_495(unsigned x)
{
    return x + 3534015113U;
}

void setval_483(unsigned *p)
{
    *p = 3252717896U;
}

void setval_383(unsigned *p)
{
    *p = 3285625166U;
}

unsigned getval_448()
{
    return 3286270280U;
}

unsigned addval_137(unsigned x)
{
    return x + 3281043848U;
}

unsigned getval_399()
{
    return 3375945385U;
}

unsigned addval_248(unsigned x)
{
    return x + 3223374489U;
}

unsigned addval_201(unsigned x)
{
    return x + 3531917993U;
}

void setval_198(unsigned *p)
{
    *p = 3281049289U;
}

unsigned getval_109()
{
    return 3674789513U;
}

void setval_337(unsigned *p)
{
    *p = 3677407881U;
}

void setval_227(unsigned *p)
{
    *p = 3372796545U;
}

unsigned addval_264(unsigned x)
{
    return x + 2447411528U;
}

void setval_126(unsigned *p)
{
    *p = 3525364361U;
}

void setval_253(unsigned *p)
{
    *p = 3222850185U;
}

void setval_353(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_489(unsigned x)
{
    return x + 3599266863U;
}

unsigned getval_285()
{
    return 3284207912U;
}

unsigned getval_484()
{
    return 1656996233U;
}

unsigned addval_470(unsigned x)
{
    return x + 2497087802U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
